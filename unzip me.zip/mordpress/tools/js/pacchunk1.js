// Global variables
var canvas = document.getElementById('canvas');
var addTextBtn = document.getElementById('addTextBtn');
var addImageBtn = document.getElementById('addImageBtn');
var addLinkBtn = document.getElementById('addLinkBtn');
var saveBtn = document.getElementById('saveBtn');
var loadBtn = document.getElementById('loadBtn');
var saveAsHtmlBtn = document.getElementById('saveAsHtmlBtn');
var pdfInput = document.getElementById('pdfInput');
var addPdfBtn = document.getElementById('addPdfBtn');
var hideBtn = document.getElementById('hideBtn');
var hidden = false;

// Add event listeners
addTextBtn.addEventListener('click', addText);
addImageBtn.addEventListener('click', addImage);
addLinkBtn.addEventListener('click', addLink);
saveBtn.addEventListener('click', saveWebsite);
loadBtn.addEventListener('click', loadCode);
saveAsHtmlBtn.addEventListener('click', saveAsHtml);
addPdfBtn.addEventListener('click', addPdf);
hideBtn.addEventListener('click', toggleChangesVisibility);

// Function to add text element
function addText() {
  var text = window.prompt('Enter text:');
  if (text !== null && text.trim() !== '') {
    var textElement = document.createElement('div');
    textElement.classList.add('text-element');
    textElement.textContent = text;
    canvas.appendChild(textElement);
  }
}

// Function to add image element
function addImage() {
  var imageElement = document.createElement('img');
  imageElement.classList.add('image-element');
  imageElement.src = 'path/to/image.jpg';
  canvas.appendChild(imageElement);
}

// Function to add link element
function addLink() {
  var link = window.prompt('Enter URL:');
  if (link !== null && link.trim() !== '') {
    var linkElement = document.createElement('a');
    linkElement.href = link;
    linkElement.textContent = 'Link';
    canvas.appendChild(linkElement);
  }
}

// Function to save the website
function saveWebsite() {
  var htmlCode = canvas.innerHTML;
  codeTextArea.value = htmlCode;
}

// Function to load code into the code editor
function loadCode() {
  var htmlCode = codeTextArea.value;
  canvas.innerHTML = htmlCode;
}

// Function to save the website as an HTML file
function saveAsHtml() {
  var htmlCode = canvas.innerHTML;
  var blob = new Blob([htmlCode], { type: 'text/html' });

  var downloadLink = document.createElement('a');
  downloadLink.href = URL.createObjectURL(blob);
  downloadLink.download = 'website.html';
  downloadLink.click();

  URL.revokeObjectURL(downloadLink.href);
}

// Function to handle adding a PDF
function addPdf() {
  pdfInput.click();
}

// Event listener for the PDF input change event
pdfInput.addEventListener('change', handlePdfInput);

// Function to handle the selected PDF file
function handlePdfInput(event) {
  var file = event.target.files[0];
  if (file) {
    // Process the selected PDF file here
    console.log('Selected PDF:', file.name);
  }
}

// Function to toggle the visibility of changes
function toggleChangesVisibility() {
  hidden = !hidden;
  if (hidden) {
    hideChanges();
  } else {
    unhideChanges();
  }
}

// Function to hide the changes
function hideChanges() {
  var changes = document.querySelectorAll('p, hr, a');
  changes.forEach(function(change) {
    change.style.display = 'none';
  });
}

// Function to unhide the changes
function unhideChanges() {
  var changes = document.querySelectorAll('p, hr, a');
  changes.forEach(function(change) {
    change.style.display = '';
  });
}


// Function to handle adding a PDF
function addPdf() {
  pdfInput.click();
}

// Event listener for the PDF input change event
pdfInput.addEventListener('change', handlePdfInput);

// Function to handle the selected PDF file
function handlePdfInput(event) {
  var file = event.target.files[0];
  if (file) {
    // Process the selected PDF file here
    console.log('Selected PDF:', file.name);
  }
}

// Function to toggle the visibility of changes
function toggleChangesVisibility() {
  hidden = !hidden;
  if (hidden) {
    hideChanges();
  } else {
    unhideChanges();
  }
}

// Function to hide the changes
function hideChanges() {
  var changes = document.querySelectorAll('p, hr, a');
  changes.forEach(function(change) {
    change.style.display = 'none';
  });
}

// Function to unhide the changes
function unhideChanges() {
  var changes = document.querySelectorAll('p, hr, a');
  changes.forEach(function(change) {
    change.style.display = '';
  });
}
